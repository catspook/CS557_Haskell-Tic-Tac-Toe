module Main where

import TicTacToe

main :: IO ()
main = play emptyBoard
