module Main where
import Test.Hspec
import TicTacToeSpec
main = hspec spec
